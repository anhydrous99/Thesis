
Evaluation Data:
data.csv
data_1.csv
data_2.csv
data_3.csv
data_4.csv
data_5.csv

Training Episode Reward Data:
run-PPO2_1-tag-episode_reward.csv
run-PPO2_2-tag-episode_reward.csv
run-PPO2_3-tag-episode_reward.csv
run-PPO2_4-tag-episode_reward.csv
run-PPO2_5-tag-episode_reward.csv
run-PPO2_6-tag-episode_reward.csv

Training Advantage Values Data:
run-PPO2_1-tag-input_info_advantage.csv
run-PPO2_2-tag-input_info_advantage.csv
run-PPO2_3-tag-input_info_advantage.csv
run-PPO2_4-tag-input_info_advantage.csv
run-PPO2_5-tag-input_info_advantage.csv
run-PPO2_6-tag-input_info_advantage.csv


Training Discounted Reward Data:
run-PPO2_1-tag-input_info_discounted_rewards.csv
run-PPO2_2-tag-input_info_discounted_rewards.csv
run-PPO2_3-tag-input_info_discounted_rewards.csv
run-PPO2_4-tag-input_info_discounted_rewards.csv
run-PPO2_5-tag-input_info_discounted_rewards.csv
run-PPO2_6-tag-input_info_discounted_rewards.csv